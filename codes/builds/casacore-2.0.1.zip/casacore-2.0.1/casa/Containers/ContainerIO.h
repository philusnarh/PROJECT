//# Added for old LOFAR release

#warning "ContainerIO.h has been deprecated; use BasicSL/STLIO.h instead."
#include <casacore/casa/BasicSL/STLIO.h>
